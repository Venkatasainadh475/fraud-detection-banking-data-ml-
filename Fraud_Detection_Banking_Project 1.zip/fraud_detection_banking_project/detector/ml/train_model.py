from pathlib import Path
import json
import numpy as np
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_FILE = BASE_DIR / "data" / "banking_transactions.csv"
MODEL_FILE = BASE_DIR / "detector" / "ml" / "fraud_model.joblib"
METRICS_FILE = BASE_DIR / "detector" / "ml" / "metrics.json"

FEATURES = [
    "amount", "transaction_type", "account_age_days", "customer_age",
    "transaction_hour", "previous_transaction_amount",
    "transactions_last_24h", "avg_transaction_amount_30d",
    "distance_from_home_km", "device_trust_score",
    "failed_login_attempts", "international"
]

def train():
    df = pd.read_csv(DATA_FILE)
    X = df[FEATURES]
    y = df["is_fraud"]

    categorical = ["transaction_type", "international"]
    numeric = [c for c in FEATURES if c not in categorical]

    preprocessor = ColumnTransformer([
        ("num", StandardScaler(), numeric),
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),
    ])

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Decision Tree": DecisionTreeClassifier(max_depth=8, random_state=42, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, max_depth=10, random_state=42, class_weight="balanced"
        ),
        "Artificial Neural Network (ANN)": MLPClassifier(
            hidden_layer_sizes=(32, 16), max_iter=500, random_state=42
        ),
    }

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    metrics = {}
    best_name, best_score, best_pipeline = None, -1, None

    for name, model in models.items():
        pipe = Pipeline([("preprocessor", preprocessor), ("model", model)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        scores = {
            "accuracy": round(accuracy_score(y_test, pred) * 100, 2),
            "precision": round(precision_score(y_test, pred, zero_division=0) * 100, 2),
            "recall": round(recall_score(y_test, pred, zero_division=0) * 100, 2),
            "f1": round(f1_score(y_test, pred, zero_division=0) * 100, 2),
        }
        metrics[name] = scores
        if scores["f1"] > best_score:
            best_name, best_score, best_pipeline = name, scores["f1"], pipe

    joblib.dump(best_pipeline, MODEL_FILE)
    METRICS_FILE.write_text(json.dumps({
        "best_model": best_name,
        "models": metrics
    }, indent=2))
    return metrics, best_name

def load_metrics():
    if not METRICS_FILE.exists():
        train()
    return json.loads(METRICS_FILE.read_text())

if __name__ == "__main__":
    result, best = train()
    print("Best model:", best)
    print(json.dumps(result, indent=2))
