from pathlib import Path
import joblib
import pandas as pd
from .train_model import MODEL_FILE, train, FEATURES

def predict_transaction(data):
    if not MODEL_FILE.exists():
        train()

    model = joblib.load(MODEL_FILE)
    row = {key: data[key] for key in FEATURES}
    frame = pd.DataFrame([row])
    label = int(model.predict(frame)[0])
    probability = float(model.predict_proba(frame)[0][1])
    return ("Fraud" if label == 1 else "No Fraud"), round(probability * 100, 2)
