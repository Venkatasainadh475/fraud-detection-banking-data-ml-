from django.contrib import admin
from .models import TransactionPrediction

@admin.register(TransactionPrediction)
class TransactionPredictionAdmin(admin.ModelAdmin):
    list_display = ("transaction_id", "user", "prediction", "fraud_probability", "created_at")
    list_filter = ("prediction", "international", "created_at")
    search_fields = ("transaction_id", "user__username")
