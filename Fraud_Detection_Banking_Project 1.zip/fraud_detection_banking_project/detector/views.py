from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from .forms import RegisterForm, TransactionForm
from .models import TransactionPrediction
from .ml.predict import predict_transaction
from .ml.train_model import load_metrics

def home(request):
    return render(request, "home.html")

def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("dashboard")
    else:
        form = RegisterForm()
    return render(request, "register.html", {"form": form})

@login_required
def dashboard(request):
    predictions = TransactionPrediction.objects.filter(user=request.user)
    total = predictions.count()
    fraud = predictions.filter(prediction="Fraud").count()
    safe = total - fraud
    return render(request, "dashboard.html", {
        "total": total, "fraud": fraud, "safe": safe
    })

@login_required
def predict(request):
    if request.method == "POST":
        form = TransactionForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data.copy()
            prediction, probability = predict_transaction(data)
            obj = form.save(commit=False)
            obj.user = request.user
            obj.prediction = prediction
            obj.fraud_probability = probability
            obj.save()
            return render(request, "result.html", {"transaction": obj})
    else:
        form = TransactionForm()
    return render(request, "predict.html", {"form": form})

@login_required
def history(request):
    rows = TransactionPrediction.objects.filter(user=request.user).order_by("-created_at")
    return render(request, "history.html", {"rows": rows})

@login_required
def accuracy(request):
    metrics = load_metrics()
    return render(request, "accuracy.html", {"metrics": metrics})
