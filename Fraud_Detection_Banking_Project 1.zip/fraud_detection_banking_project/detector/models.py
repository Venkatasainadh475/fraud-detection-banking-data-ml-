from django.contrib.auth.models import User
from django.db import models

class TransactionPrediction(models.Model):
    TRANSACTION_TYPES = [
        ("ATM", "ATM"),
        ("POS", "POS"),
        ("ONLINE", "Online"),
        ("TRANSFER", "Transfer"),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="predictions")
    transaction_id = models.CharField(max_length=50)
    amount = models.FloatField()
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPES)
    account_age_days = models.IntegerField()
    customer_age = models.IntegerField()
    transaction_hour = models.IntegerField()
    previous_transaction_amount = models.FloatField()
    transactions_last_24h = models.IntegerField()
    avg_transaction_amount_30d = models.FloatField()
    distance_from_home_km = models.FloatField()
    device_trust_score = models.FloatField()
    failed_login_attempts = models.IntegerField()
    international = models.BooleanField(default=False)
    prediction = models.CharField(max_length=20)
    fraud_probability = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.transaction_id} - {self.prediction}"
