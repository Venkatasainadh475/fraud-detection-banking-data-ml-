from django.core.management.base import BaseCommand
from detector.ml.train_model import train

class Command(BaseCommand):
    help = "Train the banking fraud detection machine-learning models."

    def handle(self, *args, **options):
        metrics, best = train()
        self.stdout.write(self.style.SUCCESS(f"Training complete. Best model: {best}"))
        for name, values in metrics.items():
            self.stdout.write(
                f"{name}: accuracy={values['accuracy']}%, "
                f"precision={values['precision']}%, "
                f"recall={values['recall']}%, f1={values['f1']}%"
            )
