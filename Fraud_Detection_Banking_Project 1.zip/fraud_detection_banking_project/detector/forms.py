from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import TransactionPrediction

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")

class TransactionForm(forms.ModelForm):
    class Meta:
        model = TransactionPrediction
        exclude = ("user", "prediction", "fraud_probability", "created_at")
        widgets = {
            "transaction_id": forms.TextInput(attrs={"placeholder": "TXN1001"}),
            "amount": forms.NumberInput(attrs={"step": "0.01"}),
            "transaction_hour": forms.NumberInput(attrs={"min": 0, "max": 23}),
            "device_trust_score": forms.NumberInput(attrs={"step": "0.01", "min": 0, "max": 1}),
        }

    def clean_transaction_hour(self):
        value = self.cleaned_data["transaction_hour"]
        if not 0 <= value <= 23:
            raise forms.ValidationError("Transaction hour must be between 0 and 23.")
        return value

    def clean_device_trust_score(self):
        value = self.cleaned_data["device_trust_score"]
        if not 0 <= value <= 1:
            raise forms.ValidationError("Device trust score must be between 0 and 1.")
        return value
