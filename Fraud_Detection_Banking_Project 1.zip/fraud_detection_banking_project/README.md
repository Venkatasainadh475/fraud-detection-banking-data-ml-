# Fraud Detection in Banking Data Using Machine Learning

Clean runnable reconstruction of the source-code section from the supplied project document.

## Technology
- Python + Django
- MySQL support (SQLite is the default demo database)
- HTML/CSS
- pandas + scikit-learn + joblib
- Machine-learning models: Logistic Regression, Decision Tree, Random Forest, Artificial Neural Network (ANN)

## Features
1. User registration and login
2. Transaction fraud prediction
3. Fraud probability
4. Prediction history
5. Model accuracy comparison
6. Django admin
7. Included sample banking transaction dataset

## Run
1. Install Python 3.10+.
2. Create and activate a virtual environment.
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env`.
5. Run `python manage.py migrate`
6. Run `python manage.py createsuperuser`
7. Optional: `python manage.py train_model`
8. Run `python manage.py runserver`
9. Open `http://127.0.0.1:8000/`

## MySQL
Set `DB_ENGINE=mysql` and fill the DB settings in `.env`. Create the database named `fraud_detection_in_banking_data`, then run migrations.

## Important
The included CSV is synthetic demonstration data, not real bank/customer data. The model is for academic demonstration and must not be used as a production banking fraud decision system without proper validation, security, monitoring, privacy controls, and domain review.
