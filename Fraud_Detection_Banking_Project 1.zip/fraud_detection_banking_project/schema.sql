CREATE DATABASE IF NOT EXISTS fraud_detection_in_banking_data CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- The Django migration system creates the application tables.
-- After setting DB_ENGINE=mysql in .env, run:
--   python manage.py migrate
--   python manage.py createsuperuser
